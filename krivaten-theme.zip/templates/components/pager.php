<ul class="article-pager">
	<li class="previous"><?php next_posts_link('<i class="icon icon-angle-left"></i> Older') ?></li>
	<li class="next"><?php previous_posts_link('Newer <i class="icon icon-angle-right"></i>') ?></li>
	<div class="clearfix"></div>
</ul>
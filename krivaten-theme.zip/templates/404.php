<?php get_header(); ?>

<section>
	<div class="container container-sm">
		<h2 class="text-center"><?php _e('Error 404 - Page Not Found'); ?></h2>
	</div>
</section>

<?php get_footer(); ?>

<?php require_once(TEMPLATEPATH . '/templates/header.php'); ?>

<section>
	<div class="container container-sm">
		<?php include(TEMPLATEPATH . '/templates/components/content.php' ); ?>
	</div>
</section>

<?php require_once(TEMPLATEPATH . '/templates/footer.php'); ?>

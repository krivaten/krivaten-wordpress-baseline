<?php $sidebarRight = true; ?>

<?php require_once(TEMPLATEPATH . '/templates/header.php'); ?>

<section>
	<div class="container container-sm">
		<?php require_once(TEMPLATEPATH . '/templates/components/excerpt.php' ); ?>
	</div>
</section>

<?php require_once(TEMPLATEPATH . '/templates/footer.php'); ?>

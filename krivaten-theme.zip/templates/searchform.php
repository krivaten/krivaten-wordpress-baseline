<form role="search" method="get" id="searchform" action="<?php echo home_url('/'); ?>">
	<input type="text" name="s" id="s" placeholder="<?php _e('Search', 'roots'); ?> <?php bloginfo('name'); ?>">
</form>
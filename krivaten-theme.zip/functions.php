<?php require("functions/index.php");?>
<?php require("functions/admin.php");?>